package controller;


import javafx.fxml.Initializable;

import javafx.scene.layout.AnchorPane;

import javax.swing.text.html.ImageView;

import java.net.URL;

import java.util.ResourceBundle;

public class SplashScreen implements Initializable {

    public AnchorPane rootPane;
    public ImageView imageView;

    /**
     * Initialize scene
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle)
    {
    }}
